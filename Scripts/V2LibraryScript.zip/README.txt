README.txt

v1.1

NOTE:  THis solution only works on a MAC.

If resigning a V24 app, then set 'viewerVersion to 24', else leave commented out.


This ANT script is used to modify the API version that DPS application is currently using.  This allows you to use the V2 API withOUT having to create a custom library.

Modify the values in the 'app.properties'.  You will need to provide P12, password, and provisioning files….and an actual IPA (development) or ZIP (distribution).

then, from a terminal window, type 'ant'.

It will create a 'resigned_xxxx.ipa' (or zip).  Use this newly created file.

